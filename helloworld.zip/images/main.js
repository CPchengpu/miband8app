const label = create_label(0,10,20,80,100);
set_label_text(label, 'hello world');
set_label_font(label, 4163);
set_label_color(label, 0x5E4B42);
set_label_content_center(label);
set_label_content_align(label);
